/* Assignment InClass04
FileName: MainActivity.java
Team Members : Vaishali Krishnamurthy,Nivedita Veeramanigandan
Student ID : 801077752, 801151512
 */

package com.example.inclass04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "demo";
    private ProgressBar progressBar;
    private SeekBar seekBar;
    private TextView tv_minvalue, tv_maxvalue, tv_avgvalue, seekbar_comp;
    Button button_calc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = findViewById(R.id.seekBar);
        tv_minvalue = findViewById(R.id.tv_minvalue);
        tv_maxvalue = findViewById(R.id.tv_maxvalue);
        tv_avgvalue = findViewById(R.id.tv_avgvalue);
        seekbar_comp = findViewById(R.id.tv_complexity);

        button_calc = findViewById(R.id.button_mainactivity);

        progressBar = findViewById(R.id.progressBar);

        seekBar.setProgress(1);
        seekBar.incrementProgressBy(1);
        seekBar.setMax(10);
        seekbar_comp.setText(String.valueOf(seekBar.getProgress())+" Times");
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progress = progress * 1;
                seekbar_comp.setText(String.valueOf(progress)+" Times");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        button_calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int complexity = seekBar.getProgress();
                new GetNumbers().execute(complexity);
            }
        });
    }

    class GetNumbers extends AsyncTask<Integer, Void, ArrayList<Double>>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(ProgressBar.VISIBLE);
        }

        @Override
        protected ArrayList<Double> doInBackground(Integer... integers) {
            return HeavyWork.getArrayNumbers(integers[0]);
        }

        @Override
        protected void onPostExecute(ArrayList<Double> doubles) {
            super.onPostExecute(doubles);
            Log.d(TAG, "onPostExecute: "+doubles.toString());

            progressBar.setVisibility(ProgressBar.INVISIBLE);

            double min = findMin(doubles);
            tv_minvalue.setText(min+"");
            double max = findMax(doubles);
            tv_maxvalue.setText(max+"");
            double avg = findAvg(doubles);
            tv_avgvalue.setText(avg+"");

        }
    }

    private  double findMin(ArrayList<Double> doubles){
        double min = Double.MAX_VALUE;
        if(doubles.size()==0){
            Toast.makeText(MainActivity.this, "Select a value between 1-10", Toast.LENGTH_SHORT).show();
            return 0;
        }
        for(double d: doubles){
            if(d<min){
                min = d;
            }
        }
        return min;
    }

    private  double findMax(ArrayList<Double> doubles){
        double max = Double.MIN_VALUE;
        if(doubles.size()==0){
            return 0;
        }
        for(double d: doubles){
            if(d>max){
                max = d;
            }
        }
        return max;
    }

    private  double findAvg(ArrayList<Double> doubles){
        double sum = 0.0;
        double avg;
        if(doubles.size()==0){
            return 0;
        }
        for(double d: doubles){
            sum = sum+d;
        }
        avg = sum/(doubles.size());
        return avg;
    }
}
