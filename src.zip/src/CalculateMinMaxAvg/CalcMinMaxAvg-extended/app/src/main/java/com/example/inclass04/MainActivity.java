/* Homework 01
FileName: MainActivity.java
Team Members : Vaishali Krishnamurthy,Nivedita Veeramanigandan
Student ID : 801077752, 801151512
 */

package com.example.inclass04;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "demo";
    ExecutorService threadPool;
    private ProgressBar progressBar;
    private SeekBar seekBar;
    private TextView tv_minvalue, tv_maxvalue, tv_avgvalue, seekbar_comp;
    Button button_calc;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        threadPool = Executors.newFixedThreadPool(2);

        seekBar = findViewById(R.id.seekBar);
        tv_minvalue = findViewById(R.id.tv_minvalue);
        tv_maxvalue = findViewById(R.id.tv_maxvalue);
        tv_avgvalue = findViewById(R.id.tv_avgvalue);
        seekbar_comp = findViewById(R.id.tv_complexity);



        button_calc = findViewById(R.id.button_mainactivity);

        progressBar = findViewById(R.id.progressBar);

        seekBar.setProgress(1);
        seekBar.incrementProgressBy(1);
        seekBar.setMax(10);
        seekbar_comp.setText(String.valueOf(seekBar.getProgress())+" Times");

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {
                if (msg.getData().containsKey("Min") &&
                msg.getData().containsKey("Max") &&
                msg.getData().containsKey("Avg")){
                    tv_minvalue.setText(msg.getData().getString("Min"));
                    tv_maxvalue.setText(msg.getData().getString("Max"));
                    tv_avgvalue.setText(msg.getData().getString("Avg"));
                    progressBar.setVisibility(View.INVISIBLE);


                }
                return true;
            }
        });
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progress = progress * 1;
                seekbar_comp.setText(String.valueOf(progress)+" Times");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        button_calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int complexity = seekBar.getProgress();
                if (complexity == 0){
                    Toast.makeText(MainActivity.this, "Select a value between 1-10", Toast.LENGTH_SHORT).show();
                }
                else {
                    threadPool.execute(new doHeavyWork(complexity));
                    progressBar.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    class doHeavyWork implements Runnable{
        int complexity = 0;

        public doHeavyWork(int complexity) {
            this.complexity = complexity;
        }

        @Override
        public void run() {
            ArrayList<Double> result = new ArrayList<Double>();
            result = HeavyWork.getArrayNumbers(this.complexity);

            double min, max, avg;
            min = findMin(result);
            max = findMax(result);
            avg = findAvg(result);


            Bundle bundle = new Bundle();
            bundle.putString("Min", "" + String.format("%.8g%n", min));
            bundle.putString("Max", "" + String.format("%.8g%n", max));
            bundle.putString("Avg", "" + String.format("%.8g%n", avg));
            Message msg = new Message();
            msg.setData(bundle);
            handler.sendMessage(msg);


        }
    }

    private  double findMin(ArrayList<Double> doubles){
        double min = Double.MAX_VALUE;
        for(double d: doubles){
            if(d<min){
                min = d;
            }
        }
        return min;
    }

    private  double findMax(ArrayList<Double> doubles){
        double max = Double.MIN_VALUE;
        for(double d: doubles){
            if(d>max){
                max = d;
            }
        }
        return max;
    }

    private  double findAvg(ArrayList<Double> doubles){
        double sum = 0.0;
        double avg;
        for(double d: doubles){
            sum = sum+d;
        }
        avg = sum/(doubles.size());
        return avg;
    }
}
