package com.example.homework02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class MusicDetails extends AppCompatActivity {

    ImageView imageView;
    TextView track_val, genre_val, album_val, artist_val, track_price_val, album_price_val;
    Button finish;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_details);
        setTitle("iTunes Music Search ");

        track_val = findViewById(R.id.md_tv_track_val);
        genre_val = findViewById(R.id.md_tv_genre_val);
        album_val = findViewById(R.id.md_tv_album_val);
        artist_val = findViewById(R.id.md_tv_artist_val);
        track_price_val = findViewById(R.id.md_tv_trackprice_val);
        album_price_val = findViewById(R.id.md_tv_albumprice_val);
        imageView = findViewById(R.id.imageView);
        finish = findViewById(R.id.bt_finish);

        Music result = (Music) getIntent().getExtras().getSerializable(MainActivity.MUSIC);
        //String trackname = result.getTrackName();
        track_val.setText(result.getTrackName());
        genre_val.setText(result.getGenre());
        artist_val.setText(result.getArtist());
        album_val.setText(result.getAlbum());
        track_price_val.setText(result.getTrackPrice().toString());
        album_price_val.setText(result.getAlbumPrice());
        Picasso.get().load(result.getImageUrl()).into(imageView);

        finish = findViewById(R.id.bt_finish);

        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homepage = new Intent(MusicDetails.this, MainActivity.class);
                //startActivity(homepage);
                MusicDetails.super.finish();
            }
        });





    }
}
