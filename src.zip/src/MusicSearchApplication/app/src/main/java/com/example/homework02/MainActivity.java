//Name: Vaishali Krishnamurthy, Nivedita Veeramanigandan
  //      Student ID: 801077752, 801151512

package com.example.homework02;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    public static String PACKAGE_NAME;

    TextView tv_limit, tv_limit_val, tv_price, tv_date;
    Button bt_search, bt_reset;
    ProgressBar pb;
    public static final String MUSIC = "music";

    SearchView searchView;
    SeekBar seekBar;
    Switch sort;

    final  ArrayList<Music> musicList = new ArrayList<>();


    String baseUrl = "https://itunes.apple.com/search";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PACKAGE_NAME = getApplicationContext().getPackageName();
        setTitle("iTunes Music Search ");

        tv_limit = findViewById(R.id.tv_limit);
        tv_limit_val = findViewById(R.id.tv_limit_val);
        tv_price = findViewById(R.id.tv_price);
        tv_date = findViewById(R.id.tv_date);
        searchView = (SearchView) findViewById(R.id.searchView);
        bt_search = findViewById(R.id.bt_seacrh);
        bt_reset = findViewById(R.id.bt_reset);
        seekBar = findViewById(R.id.seekBar);
        sort =  findViewById(R.id.switch1);
        pb = findViewById(R.id.progressBar);
        pb.setVisibility(View.INVISIBLE);


        final ListView lv_result;
        lv_result = findViewById(R.id.lv_result);


        seekBar.setProgress(10);
        seekBar.incrementProgressBy(1);
        seekBar.setMax(30);
        tv_limit_val.setText(String.valueOf(seekBar.getMin()));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progress = progress * 1;
                tv_limit_val.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        sort.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Collections.sort(musicList, new Comparator<Music>() {
                    @Override
                    public int compare(Music o1, Music o2) {
                        if (sort.isChecked() == false) {
                            if (o1.trackPrice > o2.trackPrice) {    //price sorted in descending order
                                return -1;
                            } else {
                                return 1;
                            }
                        } else {
                            Date o1Date = null;
                            Date o2Date = null;
                            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            try {
                                o1Date = format.parse(o1.date);
                                o2Date = format.parse(o2.date);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            return o1Date.compareTo(o2Date); //Date sorted in ascending order
                        }
                    }
                });


                MusicView adapter = new MusicView(MainActivity.this, R.layout.activity_music_view,musicList);
                ListView lv_result;
                lv_result = findViewById(R.id.lv_result);
                lv_result.setVisibility(View.VISIBLE);

                lv_result.setAdapter(adapter);

                lv_result.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Music m = musicList.get(position);
                        Intent sendMusic = new Intent(MainActivity.this, MusicDetails.class);
                        sendMusic.putExtra(MUSIC,m);
                        startActivity(sendMusic);
                    }
                });

            }
        });

        bt_search.setOnClickListener(new View.OnClickListener() {

            String keyword, query;
            int limit;
            Boolean switchState = sort.isEnabled();


            @Override
            public void onClick(View v) {

                query = searchView.getQuery().toString();
                if (query.length() == 0) {
                    Toast.makeText(MainActivity.this, "Enter a music related keyword", Toast.LENGTH_LONG).show();
                }
                if (query.contains(" ")) {
                    keyword = query.replace(" ", "+");
                } else {
                    keyword = query;
                }

                limit = seekBar.getProgress();
                if (isConnected()) {

                    new GetJSONData().execute(baseUrl + "?" + "term=" + keyword + "&limit=" + limit);
                }else
                {
                    Toast.makeText(MainActivity.this, "Internet Not Connected", Toast.LENGTH_SHORT).show();
                }
            }
        });



        bt_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchView.setQuery("", false);
                searchView.clearFocus();
                seekBar.setProgress(10);
                lv_result.setVisibility(View.INVISIBLE);
                musicList.clear();
            }
        });

    }


    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    private class GetJSONData extends AsyncTask<String, Void, ArrayList<Music>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pb.setVisibility(View.VISIBLE);
            musicList.clear();
        }



        @SuppressLint("WrongThread")
        @Override
        protected ArrayList<Music> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try {
                String url = strings[0];

                System.out.println(url);

                URL urlB = new URL(url);

                connection = (HttpURLConnection) urlB.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF-8");

                    JSONObject root = new JSONObject(json);
                    JSONArray music = root.getJSONArray("results");


                    for (int i = 0; i < music.length(); i++) {
                        JSONObject musicJson = music.getJSONObject(i);
                        Music a = new Music();
                        a.trackName = musicJson.getString("trackName");
                        a.trackPrice = Float.parseFloat(musicJson.getString("trackPrice"));
                        a.artist = musicJson.getString("artistName");
                        a.date = musicJson.getString("releaseDate");
                        a.album = musicJson.getString("collectionName");
                        a.albumPrice = musicJson.getString("collectionPrice");
                        a.imageUrl = musicJson.getString("artworkUrl100");
                        a.genre = musicJson.getString("primaryGenreName");
                        musicList.add(a);
                    }

                    if (sort.isChecked()) {

                        Collections.sort(musicList, new Comparator<Music>() {
                            @Override
                            public int compare(Music o1, Music o2) {

                                Date o1Date = null;
                                Date o2Date = null;
                                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                                try {
                                    o1Date = format.parse(o1.date);
                                    o2Date = format.parse(o2.date);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                                return o1Date.compareTo(o2Date);
                            }
                        });
                    } else {
                        Collections.sort(musicList, new Comparator<Music>() {
                            @Override
                            public int compare(Music o1, Music o2) {

                                if (o1.trackPrice > o2.trackPrice) {
                                    return -1;
                                } else {
                                    return 1;
                                }
                            }
                        });
                    }
                }
            }


            catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return musicList;
        }

        @Override
        protected void onPostExecute(final ArrayList<Music> music) {
            super.onPostExecute(music);
            if(music.size()==0){
                Toast.makeText(MainActivity.this, "No results found", Toast.LENGTH_LONG).show();
            }
            pb.setVisibility(View.INVISIBLE);
            ListView lv_result;
            lv_result = findViewById(R.id.lv_result);
            lv_result.setVisibility(View.VISIBLE);

            MusicView adapter = new MusicView(MainActivity.this, R.layout.activity_music_view,music);

            lv_result.setAdapter(adapter);

            lv_result.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Music m = music.get(position);
                    Intent sendMusic = new Intent(MainActivity.this, MusicDetails.class);
                    sendMusic.putExtra(MUSIC,m);
                    startActivity(sendMusic);
                }
            });

        }
    }
}
