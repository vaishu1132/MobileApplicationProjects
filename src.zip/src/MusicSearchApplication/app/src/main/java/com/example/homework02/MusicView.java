package com.example.homework02;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MusicView extends ArrayAdapter<Music> {

    public MusicView(@NonNull Context context, int resource, @NonNull ArrayList<com.example.homework02.Music> objects) {
        super(context, resource, objects);
    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Music music = getItem(position);
        ViewHolder viewHolder;

    if(convertView==null){
        convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_music_view,parent,false);
        viewHolder = new ViewHolder();
        viewHolder.track_tv = (TextView) convertView.findViewById(R.id.tv_track_val);
        viewHolder.artist_tv = (TextView) convertView.findViewById(R.id.tv_artist_val);
        viewHolder.price_tv = (TextView) convertView.findViewById(R.id.tv_price_val);
        viewHolder.date_tv = (TextView) convertView.findViewById(R.id.tv_date_val);
        convertView.setTag(viewHolder);
    }else {
        viewHolder = (ViewHolder) convertView.getTag();
    }
        if(!music.trackName.isEmpty()){viewHolder.track_tv.setText(music.trackName);}
        if(!music.artist.isEmpty()){viewHolder.artist_tv.setText(music.artist);}
        if(!music.trackPrice.equals(0)){viewHolder.price_tv.setText(music.trackPrice.toString());}
        if(!music.date.isEmpty()){

        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM-dd-yyyy");
        Date date = null;
        try {
            date = inputFormat.parse(music.date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        ;
        String formattedDate = outputFormat.format(date);


        viewHolder.date_tv.setText(formattedDate);}

        return convertView;
}


private static class ViewHolder{
    TextView price_tv;
    TextView track_tv;
    TextView artist_tv;
    TextView date_tv;
}
}
