package com.example.homework02;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Music implements Serializable {

    String trackName;
    String genre;
    String artist;
    String album;
    Float trackPrice;
    String albumPrice;
    String date;
    String imageUrl;
    Date sdate;


    public String getImageUrl() {
        return imageUrl;
    }


    public String getTrackName() {
        return trackName;
    }

    public String getGenre() {
        return genre;
    }

    public String getArtist() {
        return artist;
    }

    public String getAlbum() {
        return album;
    }

    public Float getTrackPrice() {
        return trackPrice;
    }

    public String getAlbumPrice() {
        return albumPrice;
    }


    @Override
    public String toString() {
        return "Music{" +
                "trackName='" + trackName + '\'' +
                ", genre='" + genre + '\'' +
                ", artist='" + artist + '\'' +
                ", album='" + album + '\'' +
                ", trackPrice='" + trackPrice + '\'' +
                ", albumPrice='" + albumPrice + '\'' +
                ", date=" + date +
                '}';
    }

    public Date getDate() {

        try {
             sdate = new SimpleDateFormat("MM-dd-yyyy").parse(date);

        } catch (ParseException e) {
            e.printStackTrace();
        }

        return sdate;
    }




}
