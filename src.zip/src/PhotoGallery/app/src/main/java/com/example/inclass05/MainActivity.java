/*
* Name: Vaishali Krishnamurthy, Nivedita Veeramanigandan
* Student ID: 801077752, 801151512
* */
package com.example.inclass05;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "demo";
    private TextView tv_keyword;
    private Button button_go;
    private ImageView iv_main;
    private ImageView iv_prev;
    private ImageView iv_next;
    private ProgressBar pb_progbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Main Activity");
        tv_keyword = findViewById(R.id.tv_keyword);
        iv_main = findViewById(R.id.iv_main);
        iv_prev = findViewById(R.id.iv_prev);
        iv_next = findViewById(R.id.iv_next);
        pb_progbar = findViewById(R.id.pb_progbar);
        button_go = findViewById(R.id.button_go);
        iv_next.setVisibility(View.INVISIBLE);
        iv_prev.setVisibility(View.INVISIBLE);
        button_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isConnected()) {
                    new GetKeywords(iv_main, iv_prev, iv_next, pb_progbar).execute("http://dev.theappsdr.com/apis/photos/keywords.php");

                } else {
                    Toast.makeText(MainActivity.this, "Check your Internet Connection!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }
    private class GetKeywords extends AsyncTask<String, Void, String[]> {
        ImageView iv_main;
        ImageView iv_prev;
        ImageView iv_next;
        ProgressBar pb_progbar;
        public GetKeywords(ImageView iv_main, ImageView iv_prev, ImageView iv_next, ProgressBar pb_progbar) {
            this.iv_main = iv_main;
            this.iv_prev = iv_prev;
            this.iv_next = iv_next;
            this.pb_progbar = pb_progbar;
        }
        String [] list_of_keywords = null;
        @Override
        protected String[] doInBackground(String... strings) {
            StringBuilder stringBuilder = new StringBuilder();
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            String result = null;
            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line = "";
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    result = stringBuilder.toString();
                    Log.d(TAG, "Keyword: " + result);
                    list_of_keywords = result.split(";");
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                //Close open connections and reader
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return list_of_keywords;
        }
        @Override
        protected void onPostExecute(String[] strings) {
            super.onPostExecute(strings);
            //Log.d(TAG, "onPostExecute: " +strings);
            final String[] keyword = strings;
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Select a keyword!");
            builder.setItems(keyword, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Log.d(  TAG, "Clicked On: "+keyword[which]);
                    tv_keyword.setText(keyword[which]);
                    if (keyword[which].equals("random")){
                        iv_next.setVisibility(View.INVISIBLE);
                        iv_prev.setVisibility(View.INVISIBLE);
                        Toast.makeText(MainActivity.this, "No Images Found", Toast.LENGTH_SHORT).show();
                    }
                    new GetImageURLs(iv_main,iv_prev,iv_next,pb_progbar).execute(keyword[which]);
                }
            });
            builder.create().show();
        }
    }
    private class GetImageURLs extends AsyncTask<String, Void, String[]>{
        ImageView iv_main;
        ImageView iv_prev;
        ImageView iv_next;
        ProgressBar pb_progbar;
        int url_count = 0;
        public GetImageURLs(ImageView iv_main, ImageView iv_prev, ImageView iv_next, ProgressBar pb_progbar) {
            this.iv_main = iv_main;
            this.iv_prev = iv_prev;
            this.iv_next = iv_next;
            this.pb_progbar = pb_progbar;
            iv_next.setVisibility(View.VISIBLE);
            iv_prev.setVisibility(View.VISIBLE);

        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected String[] doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            String[] list_of_images = null;
            String result = null;
            StringBuilder stringBuilder = new StringBuilder();
            try{
                String strUrl = "http://dev.theappsdr.com/apis/photos/index.php" + "?" + "keyword=" + strings[0];
                URL url = new URL(strUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line = "";
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line + " ");
                    }
                    result = stringBuilder.toString();
                    list_of_images = result.split(" ");
                }
            }catch (UnsupportedEncodingException e){
                e.printStackTrace();
            }catch (MalformedURLException e){
                e.printStackTrace();
            }catch (IOException e){
                e.printStackTrace();
            }finally {
                //Close open connections and reader
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return list_of_images;
        }
        @Override
        protected void onPostExecute(final String[] strings) {
            super.onPostExecute(strings);
            Log.d(TAG, "post Image URLs: "+strings);
            url_count = 0;
            new GetImageFetcher(iv_main,iv_prev,iv_next,pb_progbar).execute(strings[url_count]);
            iv_prev.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(url_count == 0){
                        url_count = strings.length - 1;
                    }else{
                        --url_count;
                    }
                    new GetImageFetcher(iv_main,iv_prev,iv_next,pb_progbar).execute(strings[url_count]);
                }
            });
            iv_next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(url_count == strings.length-1){
                        url_count = 0;
                    }else{
                        ++url_count;
                    }
                    new GetImageFetcher(iv_main,iv_prev,iv_next,pb_progbar).execute(strings[url_count]);
                }
            });
        }
    }
    class GetImageFetcher extends AsyncTask<String, Void, Bitmap> {
        ImageView iv_main;
        ImageView iv_prev;
        ImageView iv_next;
        ProgressBar pb_progbar;
        Bitmap bitmap = null;
        public GetImageFetcher(ImageView iv_main, ImageView iv_prev, ImageView iv_next, ProgressBar pb_progbar) {
            this.iv_main = iv_main;
            this.iv_prev = iv_prev;
            this.iv_next = iv_next;
            this.pb_progbar = pb_progbar;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pb_progbar.setVisibility(View.VISIBLE);
        }
        @Override
        protected Bitmap doInBackground(String... strings) {
            Log.d("demo",strings[0]);
            HttpURLConnection connection = null;
            bitmap = null;
            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    bitmap = BitmapFactory.decodeStream(connection.getInputStream());
                }
            } catch (Exception e) {
                e.printStackTrace();
                //Handle the exceptions
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                //Close open connection
            }
            return bitmap;
        }
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            pb_progbar.setVisibility(View.INVISIBLE);
            if (bitmap != null && iv_main != null) {
                //Log.d("jee",bitmap+"");
                iv_main.setImageBitmap(bitmap);
            }
        }
    }
}