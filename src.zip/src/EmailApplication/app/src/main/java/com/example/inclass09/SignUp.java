package com.example.inclass09;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SignUp extends AppCompatActivity {

    EditText et_fName, et_lName, et_email_sup, et_pass_sup, et_pass_repeat;
    Button bt_signup_sup, bt_cancel;
    String email, password, fname, lname;
    Handler handler = new Handler();
    String msg = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        setTitle("Sign Up");

        et_fName = findViewById(R.id.et_firstName);
        et_lName = findViewById(R.id.et_lastName);
        et_email_sup = findViewById(R.id.et_email_signup);
        et_pass_sup = findViewById(R.id.et_password_signup);
        et_pass_repeat = findViewById(R.id.et_repeatpassword);
        bt_signup_sup = findViewById(R.id.bt_signup_signuppage);
        bt_cancel = findViewById(R.id.bt_cancel);

        bt_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SignUp.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        bt_signup_sup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isConnected()){
                    Toast.makeText(SignUp.this, "Check your internet connection!", Toast.LENGTH_SHORT).show();
                }
                else if(et_fName.equals("")){
                    et_fName.setError("Enter your firstname");
                }
                else if(et_lName.equals("")){
                    et_lName.setError("Enter your lastname");
                }
                else if(et_email_sup.equals("") || !android.util.Patterns.EMAIL_ADDRESS.matcher(et_email_sup.getText().toString().trim()).matches()){
                    et_email_sup.setError("Enter a valid email");
                }
                else if(et_pass_sup.equals("")){
                    et_pass_sup.setError("Enter a password");
                }
                else if(et_pass_repeat.equals("")){
                    et_pass_repeat.setError("Confirm password");
                }
                else if(!et_pass_sup.getText().toString().equals(et_pass_repeat.getText().toString())) {
                    et_pass_repeat.setError("Passwords do not match");
                }
                else {
                    fname = et_fName.getText().toString();
                    lname = et_lName.getText().toString();
                    email = et_email_sup.getText().toString();
                    password = et_pass_sup.getText().toString();
                    new GetSignUpAsync().execute("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/signup");
                }
            }
        });
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    private class GetSignUpAsync extends AsyncTask<String, Void, String>{

        private final OkHttpClient client = new OkHttpClient();

        @Override
        protected String doInBackground(String... strings) {
            RequestBody formBody = new FormBody.Builder()
                    .add("email", email)
                    .add("password", password)
                    .add("fname", fname)
                    .add("lname", lname)
                    .build();

            Request request = new Request.Builder()
                    .url(strings[0])
                    .post(formBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {

                    try {
                        String json = response.body().string();
                        JSONObject root = new JSONObject(json);
                        msg = root.getString("message");

                        handler.post( new Runnable() {
                            public void run() {
                                Toast.makeText(getApplicationContext(), "" + msg, Toast.LENGTH_LONG).show();
                            }
                        });
                        //Toast.makeText(getApplicationContext(), ""+message, Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    throw new IOException("Unexpected code " + response);
                }
                return response.body().string();

            }

            catch (MalformedURLException e) {
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            finally {
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            if (s != null) {

                Gson g = new Gson();
                TokenDetails user = g.fromJson(s, TokenDetails.class);
                SharedPreferences sp = getSharedPreferences("user",MODE_PRIVATE);
                SharedPreferences.Editor spEditor = sp.edit();
                spEditor.putString("token",user.token);
                spEditor.putString("firstname",user.user_fname);
                spEditor.putString("lastname",user.user_lname);
                spEditor.apply();

                Toast.makeText(SignUp.this, user.user_fname + " successfully created!", Toast.LENGTH_SHORT).show();

                finish();
                Intent i = new Intent(SignUp.this, InboxView.class);
                startActivity(i);

            } else {
                Toast.makeText(SignUp.this, "Error signing up. Try again!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
