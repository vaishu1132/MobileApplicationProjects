package com.example.inclass09;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class InboxView extends AppCompatActivity implements RecyclerActivity.InteractWithRecyclerView{
    TextView tv_name;
    ImageView iv_new, iv_logout;
    RecyclerView rv;
    private RecyclerView.Adapter rv_adapter;
    private RecyclerView.LayoutManager rv_layout;
    String fname, lname;
    final ArrayList<Message> r = new ArrayList<Message>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inbox_view);
        setTitle("Inbox");

        tv_name = findViewById(R.id.tv_name);
        iv_new = findViewById(R.id.iv_addnew);
        iv_logout = findViewById(R.id.iv_logout);
        rv = findViewById(R.id.recyclerView);

        SharedPreferences sp = getSharedPreferences("user", MODE_PRIVATE);
        fname = sp.getString("firstname","0");
        lname = sp.getString("lastname","0");
        tv_name.setText(fname+" "+lname);
        rv.setHasFixedSize(true);

        rv_layout = new LinearLayoutManager(this);
        rv.setLayoutManager(rv_layout);


        if(isConnected()){
            new GetChatAsync().execute("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/inbox");
        }else{
            Toast.makeText(this, "Check your internet connection!", Toast.LENGTH_SHORT).show();
        }

        iv_new.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(InboxView.this,NewMail.class);
                startActivity(i);
            }
        });
        iv_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(InboxView.this,MainActivity.class);
                startActivity(i);
            }
        });

        rv_adapter = new RecyclerActivity(r, this);
        rv.setAdapter(rv_adapter);
    }

    private boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }


    class GetChatAsync extends AsyncTask<String, Void, String> {
        private final OkHttpClient client = new OkHttpClient();
        @Override
        protected String doInBackground(String... strings) {
            SharedPreferences sp = getSharedPreferences("user",MODE_PRIVATE);
            String token = sp.getString("token",null);
            //String body;
            if(token == null){
                Log.d("report","token is not found");
            }

            try {

                Request request = new Request.Builder()
                        .url(strings[0])
                        .addHeader("Authorization", "BEARER " + token)
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                    return response.body().string();

                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            finally {
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try{
                JSONObject root = new JSONObject(s);
                JSONArray messages =   root.getJSONArray("messages");

                for(int i=0; i<messages.length(); i++ ){
                    JSONObject message = messages.getJSONObject(i);

                    Message m = new Message();
                    m.sender_fname = message.getString("sender_fname");
                    m.sender_lname = message.getString("sender_lname");
                    m.id = message.getString("id");
                    m.sender_id = message.getString("sender_id");
                    m.receiver_id = message.getString("receiver_id");
                    m.message = message.getString("message");
                    m.subject = message.getString("subject");
                    m.created_at = message.getString("created_at");
                    m.updated_at = message.getString("updated_at");
                    r.add(m);
                }
            }
            catch (JSONException e){
                e.printStackTrace();
            }

        }

    }

    @Override
    public void deleteItem(int position) {
        r.remove(position);
        new DeleteMessageAsync().execute("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/inbox/delete/"+r.get(position).id);
        if (r.size()>=0) {
            rv_adapter.notifyDataSetChanged();
        }
        else{
            rv.setAdapter(null);
        }
    }

    public class DeleteMessageAsync extends AsyncTask<String, Void, String>{
        private final OkHttpClient client = new OkHttpClient();
        @Override
        protected String doInBackground(String... strings) {
            SharedPreferences sp = getSharedPreferences("user",MODE_PRIVATE);
            String token = sp.getString("token",null);
            if(token == null){
                Log.d("report","token is not found");
            }
            try{
                Request.Builder request = new Request.Builder()
                        .url(strings[0])
                        .addHeader("Authorization", "BEARER " + token)
                        .delete();

                try (Response response = client.newCall(request.build()).execute()) {
                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                    return response.body().string();

                }

            } catch (Exception e) {
                e.printStackTrace();
            }finally {
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(InboxView.this, "Deleted Mail", Toast.LENGTH_SHORT).show();
        }

    }

}
