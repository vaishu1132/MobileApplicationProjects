package com.example.inclass09;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerActivity extends RecyclerView.Adapter<RecyclerActivity.ViewHolder> {

   ArrayList<Message> mdata;
   static String CHAT_KEY = "chat";
   public static InteractWithRecyclerView interact;
   Context ctx;

    public RecyclerActivity(ArrayList<Message> mdata, Context inboxView) {
        this.mdata = mdata;
        this.ctx = inboxView;

    }

    @NonNull
    @Override
    public RecyclerActivity.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_recycler,parent,false);
        ViewHolder vh = new ViewHolder(view);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerActivity.ViewHolder holder, final int position) {
        interact = (InteractWithRecyclerView) ctx;
        final Message s = mdata.get(position);
       // Log.d("fruit",holder.tv_subject.getLineCount()+"");
        holder.tv_subject.setText(s.getSubject());
        System.out.println("helllllllllo");
        holder.tv_date.setText(s.created_at);
        holder.message = s;
        holder.iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Log.d("demo", "Delete clicked from: "+s.id);
                interact.deleteItem(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mdata.size();
    }

    public interface InteractWithRecyclerView {
        void deleteItem(int position);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_subject, tv_date;
        ImageButton iv_delete;
        Message message;

        @Override
        public String toString() {
            return super.toString();
        }

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            tv_subject = itemView.findViewById(R.id.tv_subject);
            tv_date = itemView.findViewById(R.id.tv_date);
            iv_delete = (ImageButton) itemView.findViewById(R.id.iv_delete);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(itemView.getContext(), MailDisplay.class);
                    i.putExtra(CHAT_KEY, message);
                    v.getContext().startActivity(i);


                }
            });

        }
    }

}
