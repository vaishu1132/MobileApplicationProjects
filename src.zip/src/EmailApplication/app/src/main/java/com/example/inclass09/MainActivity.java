package com.example.inclass09;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.io.IOException;
import java.net.MalformedURLException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    Handler handler = new Handler();
    EditText login_email, login_password;
    Button bt_login, bt_signup;
    String email, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Mailer");

        login_email = findViewById(R.id.et_loginemail);
        login_password = findViewById(R.id.et_loginpassword);
        bt_login = findViewById(R.id.bt_login);
        bt_signup = findViewById(R.id.bt_signup_loginpage);


        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isConnected()) {
                    if (login_email.equals("")) {
                        login_email.setError("Enter your email");
                        Toast.makeText(MainActivity.this, "Enter emailID", Toast.LENGTH_SHORT).show();
                    } else if (login_password.equals("")) {
                        login_password.setError("Enter password");
                        Toast.makeText(MainActivity.this, "Enter password", Toast.LENGTH_SHORT).show();
                    } else {
                        email = login_email.getText().toString();
                        password = login_password.getText().toString();
                        new GetLoginAsync().execute("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/login");
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Check your internet connection!", Toast.LENGTH_SHORT).show();
                }

            }
        });

        bt_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, SignUp.class);
                startActivity(i);
                finish();
            }
        });

    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    private class GetLoginAsync extends AsyncTask<String, Void, String>{

        final OkHttpClient client = new OkHttpClient();
        @Override
        protected String doInBackground(String... strings) {
            try {
                RequestBody formBody = new FormBody.Builder()
                        .add("email", email)
                        .add("password", password)
                        .build();

                Request request = new Request.Builder()
                        .url(strings[0])
                        .post(formBody)
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
                    handler.post( new Runnable() {
                        public void run() {
                            Toast.makeText(getApplicationContext(), "hello" , Toast.LENGTH_LONG).show();
                        }
                    });
                    return response.body().string();

                }
            }catch (MalformedURLException e){
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            }finally {
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            if(s!=null){
                Gson g = new Gson();
                TokenDetails user = g.fromJson(s,TokenDetails.class);

                SharedPreferences sp = getSharedPreferences("user", MODE_PRIVATE);
                SharedPreferences.Editor spEditor = sp.edit();
                spEditor.putString("token",user.token);
                spEditor.putString("firstname",user.user_fname);
                spEditor.putString("lastname",user.user_lname);
                spEditor.apply();

                finish();
                Intent in = new Intent(MainActivity.this, InboxView.class);
                startActivity(in);
            }else {
                Toast.makeText(MainActivity.this, "Login unsuccessful, please try again!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
