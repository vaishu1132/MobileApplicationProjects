package com.example.inclass09;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MailDisplay extends AppCompatActivity {

    TextView tv_sentby, tv_subjectdisp, tv_messagedisp, tv_createdat;
    Button bt_goback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mail_display);

        setTitle("Display Mail");

        tv_sentby = findViewById(R.id.tv_sentby);
        tv_subjectdisp = findViewById(R.id.tv_subjectdisp);
        tv_messagedisp = findViewById(R.id.tv_messagedisp);
        tv_createdat = findViewById(R.id.tv_createdat);
        bt_goback = findViewById(R.id.bt_goback);

        if(getIntent().getExtras()!=null){
            Message msg = (Message) getIntent().getExtras().getSerializable(RecyclerActivity.CHAT_KEY);
            tv_sentby.setText(msg.sender_fname);
            tv_subjectdisp.setText(msg.subject);
            tv_messagedisp.setText(msg.message);
            tv_createdat.setText(msg.created_at);
        }

        bt_goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
