//Name: Vaishali Krishnamurthy, Nivedita Veeramanigandan
//Student ID: 801077752, 801151512
package com.example.inclass13;

import androidx.fragment.app.FragmentActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        String json = getJsonFromAssets(this, "trip-1.json");
        Locations locations = getLocationsfromJson(json);
        ArrayList<Location> points = locations.points;
        PolylineOptions polylineOptions = new PolylineOptions();
        LatLngBounds.Builder latlngbuilder = new LatLngBounds.Builder();
        for (int i=0; i<points.size(); i++) {

            Polyline polyline = googleMap.addPolyline(new PolylineOptions()
                    .add(new LatLng(points.get(i).latitude, points.get(i).longitude)));

            LatLng point = new LatLng(points.get(i).latitude, points.get(i).longitude);
            polylineOptions.add(point);
            latlngbuilder.include(point);
        }
        mMap.addPolyline( polylineOptions );
        mMap.addMarker(new MarkerOptions().position(new LatLng(points.get(0).latitude,points.get(0).longitude)).title("Start Location"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(points.get(points.size()-1).latitude,points.get(points.size()-1).longitude)).title("End Location"));
        final LatLngBounds latLngBounds = latlngbuilder.build();
        Log.d("demo", "onMapReady: "+ latLngBounds);


        mMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, 50));
                mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, 50));
            }
        });
    }

    String getJsonFromAssets(Context context, String fileName) {
        String jsonString;
        try {
            InputStream is = context.getAssets().open(fileName);

            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            jsonString = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        return jsonString;
    }

    public Locations getLocationsfromJson(String json){
        Gson gson = new Gson();
        Locations locations = gson.fromJson(json, Locations.class);
        return locations;

    }
}
