package com.example.inclass06;

public class News {
    String title;
    String publish;
    String urlToImage;
    String desription;

    @Override
    public String toString() {
        return "News{" +
                "title='" + title + '\'' +
                ", publish='" + publish + '\'' +
                ", urlToImage='" + urlToImage + '\'' +
                ", desription='" + desription + '\'' +
                '}';
    }

    public News() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublish() {
        return publish;
    }

    public void setPublish(String publishedAt) {
        this.publish = publishedAt;
    }

    public String getUrlToImage() {
        return urlToImage;
    }

    public void setUrlToImage(String urlToImage) {
        this.urlToImage = urlToImage;
    }

    public String getDesription() {
        return desription;
    }

    public void setDesription(String desription) {
        this.desription = desription;
    }
}
