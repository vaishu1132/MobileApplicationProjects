/*
* Name: Vaishali Krishnamurthy, Nivedita Veeramanigandan
* Student ID: 801077752, 801151512
* InClass06
* Group08
*/

package com.example.inclass06;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView tv_category;
    private Button button_select;
    private TextView tv_title;
    private TextView tv_publish;
    private TextView tv_description;
    private ImageView iv_image;
    private ImageView iv_prev;
    private ImageView iv_next;
    private TextView tv_count;
    int count =0;

    String[] category = {"business", "entertainment","general","health","science","sports","technology"};
    String baseURL = "http://newsapi.org/v2/top-headlines";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Main Activity");

        tv_category = findViewById(R.id.tv_category);
        button_select = findViewById(R.id.button_select);
        tv_title = findViewById(R.id.tv_title);
        tv_publish = findViewById(R.id.tv_publish);
        tv_description = findViewById(R.id.tv_description);
        iv_image = findViewById(R.id.iv_image);
        iv_prev = findViewById(R.id.iv_prev);
        iv_next = findViewById(R.id.iv_next);
        tv_count = findViewById(R.id.tv_count);

        iv_prev.setVisibility(View.INVISIBLE);
        iv_next.setVisibility(View.INVISIBLE);

        button_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isConnected()){
                AlertDialog.Builder build = new AlertDialog.Builder(MainActivity.this);
                build.setTitle("Choose Category");
                build.setCancelable(true);

                build.setItems(category, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String selectedcat = category[which];
                        String sel_cat = selectedcat.substring(0, 1).toUpperCase() + selectedcat.substring(1);
                        tv_category.setText(sel_cat);

                        new GetJSONData().execute(selectedcat);
                    }
                });
                build.show();
                }else{
                    Toast.makeText(MainActivity.this, "No Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    private class GetJSONData extends AsyncTask<String, Void, ArrayList<News>>{
        ProgressDialog progdialog = new ProgressDialog(MainActivity.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progdialog.show();
            progdialog.setMessage("Loading News ...");
        }

        @Override
        protected ArrayList<News> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            ArrayList<News> newsList= new ArrayList<>();
            String category = strings[0];
            try {
                String url = baseURL+"?"+"apiKey="+getResources().getString(R.string.news_key)+"&"+"category="+
                        URLEncoder.encode(category,"UTF-8");

                URL urlB = new URL(url);

                connection = (HttpURLConnection) urlB.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF-8");

                    JSONObject root = new JSONObject(json);
                    JSONArray news = root.getJSONArray("articles");
                    for (int i=0;i<news.length();i++) {
                        JSONObject newsJson = news.getJSONObject(i);
                        News a = new News();
                        a.title = newsJson.getString("title");
                        a.publish = newsJson.getString("publishedAt");
                        a.desription = newsJson.getString("description");
                        a.urlToImage = newsJson.getString("urlToImage");

                        newsList.add(a);
                    }


                }
            }catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return newsList;
        }

        void getNews(ArrayList<News> result, int count){
            tv_title.setText(result.get(count).getTitle());
            Picasso.get().load(result.get(count).getUrlToImage()).into(iv_image);
            tv_publish.setText(result.get(count).getPublish());
            if(result.get(count).getDesription()=="null"){
                //Toast.makeText(MainActivity.this, "No Description found", Toast.LENGTH_SHORT).show();
                tv_description.setText("No description found");
            } else{
                tv_description.setText(result.get(count).getDesription());
            }
            int newCount=count+1;
            tv_count.setText(newCount + " out of 20");
        }

        @Override
        protected void onPostExecute(final ArrayList<News> news) {
            super.onPostExecute(news);
            if (news.size() > 0) {
                iv_next.setVisibility(View.VISIBLE);
                iv_prev.setVisibility(View.VISIBLE);
                progdialog.dismiss();
                count = 0;
                getNews(news,count);

                iv_prev.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(count == 0) {
                            count = 19;
                            getNews(news,count);
                        } else {
                            count--;
                            getNews(news,count);

                        }


                    }
                });

                iv_next.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(count == 19){
                            count =0;
                            getNews(news,count);
                        } else {
                            count++;
                            getNews(news,count);
//
                        }

                    }
                });
                Log.d("demo", news+"");
            } else {
                Log.d("demo", "No News found!");
            }
        }
    }


}
