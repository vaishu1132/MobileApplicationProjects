package com.example.inclass07;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import android.annotation.SuppressLint;
import android.widget.Toast;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import static com.example.inclass07.MainActivity.QUIZ;


public class TriviaActivity extends AppCompatActivity implements MyAdapter.InteractWithTriviaActivity {

    TextView tv_quesno, tv_qn, tv_timer;
    ImageView iv_qnimage;
    ProgressBar pb_qnimage;
    RecyclerView recyclerView;
    RecyclerView.Adapter rv_adapter;
    RecyclerView.LayoutManager rv_layoutManager;
    Button bt_next, bt_quit;
    final String RESULT = "result";
    private CountDownTimer countDownTimer;
    private boolean intentExists = false;
    ArrayList<Quiz> questionList = new ArrayList<Quiz>();

    ArrayList<String> choices = null;
    private int qn_count = 0;
    private int correctans = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia);

        tv_quesno = findViewById(R.id.tv_quesno);
        tv_qn = findViewById(R.id.tv_qn);
        tv_timer = findViewById(R.id.tv_timer);
        iv_qnimage = findViewById(R.id.iv_qnimage);
        bt_next = findViewById(R.id.button_next);
        bt_quit = findViewById(R.id.button_quit);
        pb_qnimage = findViewById(R.id.progressBar_qnimage);
        questionList = (ArrayList<Quiz>) getIntent().getExtras().getSerializable(QUIZ);
        choices = questionList.get(0).choices;
        recyclerView = findViewById(R.id.rv_options);

        tv_timer.setText("");
        countDownTimer = new CountDownTimer(2 * 60 * 1000, 1000) {
            @Override
            public void onTick(long l) {
                long minute = l / 1000 / 60;
                long second = (l - minute * 60 * 1000) / 1000;
                Log.d("Demo", "onTick: " + minute + " " + second);
                tv_timer.setText(minute + " : " + second);
            }

            @Override
            public void onFinish() {
                callIntent();
            }
        };
        countDownTimer.start();
        getNextQuestion();
        findViewById(R.id.button_next).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qn_count++;
                getNextQuestion();
            }
        });

        findViewById(R.id.button_quit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countDownTimer.onFinish();
            }
        });
    }

    public void callIntent() {
        if (!intentExists) {
            double percent;
            percent = correctans * 100 / questionList.size();
            Intent intent = new Intent(TriviaActivity.this, TriviaStats.class);
            intent.putExtra("percentage", percent);
            //intent.putExtra("totalquestions", quizDataArrayList.size() );
            startActivityForResult(intent, 100);
            intentExists = true;
        }
    }


    public void getNextQuestion() {
        if (qn_count < questionList.size()) {
            pb_qnimage.setVisibility(ProgressBar.VISIBLE);
            TextView questionNumber = findViewById(R.id.tv_quesno);
            TextView question = findViewById(R.id.tv_qn);
            int number = questionList.get(qn_count).id;
            int questionCounter = Integer.valueOf(number) + 1;
            questionNumber.setText("Q" + String.valueOf(questionCounter));
            ImageView imageView = findViewById(R.id.iv_qnimage);
            if (questionList.get(qn_count).imageUrl.equals("")) {
                imageView.setImageResource(R.drawable.ic_launcher_background);
                pb_qnimage.setVisibility(ProgressBar.INVISIBLE);
            } else {
                Picasso.get().load(questionList.get(qn_count).imageUrl)
                        .into(imageView, new Callback() {
                            @Override
                            public void onSuccess() {
                                pb_qnimage.setVisibility(ProgressBar.INVISIBLE);
                            }

                            @Override
                            public void onError(Exception e) {
                                Toast.makeText(TriviaActivity.this, "No Image found", Toast.LENGTH_SHORT).show();
                                pb_qnimage.setVisibility(ProgressBar.INVISIBLE);
                            }
                        });
            }
            question.setText(questionList.get(qn_count).text);
            //For Recycler Views:
            recyclerView = (RecyclerView) findViewById(R.id.rv_options);

            rv_layoutManager = new LinearLayoutManager(this);
            recyclerView.setLayoutManager(rv_layoutManager);

            // specify an adapter (see also next example)
            MyAdapter myAdapter = new MyAdapter(questionList.get(qn_count).choices, this);
            recyclerView.setAdapter(myAdapter);


        } else {
            countDownTimer.onFinish();
        }
    }


    @Override
    public void getItemPosition(int position) {
        if (qn_count < questionList.size()) {
            if (questionList.get(qn_count).answer == (position + 1)) {
                correctans++;
            }
            qn_count++;
            getNextQuestion();
        }

    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 100){
            int doActivity = data.getExtras().getInt("getValue");
            if(doActivity == 1){
                finish();
            }else if(doActivity == 2){
                qn_count = 0;
                correctans = 0;
                intentExists = false;
                //sizeArrayList = quizDataArrayList.size();
                tv_timer = findViewById(R.id.tv_timer);
                tv_timer.setText("");
                countDownTimer.start();
                getNextQuestion();
            }
        }
    }
}
