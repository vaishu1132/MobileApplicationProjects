package com.example.inclass07;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
public class Quiz implements Serializable {
    int id, answer;
    String text, imageUrl;
    ArrayList<String> choices = new ArrayList<>();
    @Override
    public String toString() {
        return "Quiz{" +
                "id=" + id +
                ", answer=" + answer +
                ", text='" + text + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", choices=" + choices.toString() +
                '}';
    }
    public int getId() {
        return id;
    }
    public int getAnswer() {
        return answer;
    }
    public String getText() {
        return text;
    }
    public String getImageUrl() {
        return imageUrl;
    }
    public ArrayList<String> getChoices() {
        return choices;
    }
}