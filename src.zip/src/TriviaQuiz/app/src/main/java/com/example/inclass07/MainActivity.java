package com.example.inclass07;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    RecyclerView.Adapter rv_adapter;
    RecyclerView.LayoutManager rv_layoutManager;
    ArrayList<Quiz> questions;
    String TAG = "demo";
    Button bt_exit, bt_start;
    TextView tv_loading;
    ProgressBar progressBar;
    ImageView iv_trivia;
    final ArrayList<Quiz> questionList = new ArrayList<>();
    public static final String QUIZ = "quiz";
    String baseUrl = "http://dev.theappsdr.com/apis/trivia_json/index.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt_start = findViewById(R.id.button_start);
        bt_start.setEnabled(false);
        bt_exit = findViewById(R.id.button_exit);
        tv_loading = findViewById(R.id.textView3);
        progressBar = findViewById(R.id.progressBar);
        iv_trivia = findViewById(R.id.iv_trivia);
        questions = new ArrayList<>();

        bt_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TriviaActivity.class);
                intent.putExtra(QUIZ,questionList);
                startActivity(intent);

            }
        });

        bt_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });

        if (isConnected()) {
            new GetJSONData().execute(baseUrl);
        } else {
            Toast.makeText(this, "Internet Not Connected", Toast.LENGTH_SHORT).show();
        }
    }
    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }
    private class GetJSONData extends AsyncTask<String, Void, ArrayList<Quiz>> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            //bt_start.setEnabled(false);
            questionList.clear();
        }
        @Override
        protected ArrayList<Quiz> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            //String [] choiceArray = null;
            ArrayList<String> choiceArray = new ArrayList<>();
            try {
                String url = strings[0];
                System.out.println(url);
                URL urlB = new URL(url);
                connection = (HttpURLConnection) urlB.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF-8");
                    JSONObject root = new JSONObject(json);
                    JSONArray questions = root.getJSONArray("questions");
                    for (int i = 0; i < questions.length(); i++) {
                        JSONObject qJson = questions.getJSONObject(i);
                        Quiz q = new Quiz();
                        q.id = qJson.getInt("id");
                        q.text = qJson.getString("text");
                        q.imageUrl = "";
                        try{
                            q.imageUrl = qJson.getString("image");
                        }catch (Exception e){
                            Log.d("demo", "No image available for this question");
                        }
                        JSONObject choices = qJson.getJSONObject("choices");
                        q.answer = Integer.parseInt(choices.getString("answer"));
                        JSONArray choice = choices.getJSONArray("choice");
                        for (int j = 0 ; j < choice.length(); j++){
                            q.choices.add(choice.getString(j));
                            //choiceArray[j] = choice.getString(j);
                            //choiceArray[j] = choice.optString(j);
                            //choiceArray.add(choice.get(j).toString());
                            //questionList.add(q);
                        }
                        //q.choices = choiceArray;
                        //q.choices.clone(choiceArray)
                        //System.arraycopy(choiceArray,0,q.choices,0,choiceArray.size());
                        //System.out.println(q.choices);
                        questionList.add(q);
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            //System.out.println(questionList);
            return questionList;
        }
        @Override
        protected void onPostExecute(ArrayList<Quiz> quizzes) {
            super.onPostExecute(quizzes);
            iv_trivia.setVisibility(View.VISIBLE);
            tv_loading.setText("Trivia Ready");
            bt_start.setEnabled(true);

        }
    }
}