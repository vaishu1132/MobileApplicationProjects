package com.example.inclass07;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class TriviaStats extends AppCompatActivity {

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        ProgressBar progressBar = findViewById(R.id.progressBar_percent);
        TextView textview = findViewById(R.id.tv_percent);
        double percent =  getIntent().getExtras().getDouble("percentage");

        textview.setText(String.valueOf((int)percent)+"%");
        TextView message = findViewById(R.id.tv_comment);
        if((int) percent == 100){
            message.setText("Well done!!!");
        }else{
            message.setText("Try again and see if you can get all the correct answers!");
        }
        progressBar.setProgress((int) percent);
        findViewById(R.id.button_statsquit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent data = new Intent();
                data.putExtra("getValue",1);
                setResult(200, data);
                finish();
            }
        });

        findViewById(R.id.button_statstry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent data = new Intent();
                data.putExtra("getValue",2);
                setResult(200, data);
                finish();
            }
        });
    }

}
