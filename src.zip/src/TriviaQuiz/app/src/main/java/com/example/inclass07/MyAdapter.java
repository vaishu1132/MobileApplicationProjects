package com.example.inclass07;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    public static InteractWithTriviaActivity interact;
    //Context ctx;

    ArrayList<String> options = new ArrayList<String>();
    static String TAG = "demo";

    public MyAdapter(ArrayList<String> options, Context mainActivity) {
        this.options = options;
        interact = (InteractWithTriviaActivity) mainActivity;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rv_layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(rv_layout);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        String sel_option = options.get(position);
        holder.tv_option.setText(sel_option);
        holder.tv_option.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Log.d("Demo","Selected Choice is : "+options.get(position));
                interact.getItemPosition(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return options.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_option;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_option = itemView.findViewById(R.id.tv_option);
        }
    }

    public interface InteractWithTriviaActivity{
       void getItemPosition(int position);
    }

}
