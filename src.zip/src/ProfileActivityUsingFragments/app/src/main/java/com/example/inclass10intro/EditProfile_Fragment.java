package com.example.inclass10intro;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

//
///**
// * A simple {@link Fragment} subclass.
// * Use the {@link EditProfile_Fragment#newInstance} factory method to
// * create an instance of this fragment.
// */
public class EditProfile_Fragment extends Fragment {
//    // TODO: Rename parameter arguments, choose names that match
//    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
//    private static final String ARG_PARAM1 = "param1";
//    private static final String ARG_PARAM2 = "param2";

    ToAvatarFromEdit mContext;
    ToDisplayFromEdit dContext;

    private EditText et_fname, et_lname;
    private Button button_Save;
    private ImageView iv_avatar;
    private String gender="";


//
//    // TODO: Rename and change types of parameters
//    private String mParam1;
//    private String mParam2;

    public EditProfile_Fragment() {
        // Required empty public constructor
    }

    public void setGender(String gender){
        this.gender = gender;

    }

//    /**
//     * Use this factory method to create a new instance of
//     * this fragment using the provided parameters.
//     *
//     * @param param1 Parameter 1.
//     * @param param2 Parameter 2.
//     * @return A new instance of fragment EditProfile_Fragment.
//     */
//    // TODO: Rename and change types and number of parameters
//    public static EditProfile_Fragment newInstance(String param1, String param2) {
//        EditProfile_Fragment fragment = new EditProfile_Fragment();
//        Bundle args = new Bundle();
//        args.putString(ARG_PARAM1, param1);
//        args.putString(ARG_PARAM2, param2);
//        fragment.setArguments(args);
//        return fragment;
//    }


    @Override
    public void onResume() {
        super.onResume();
        iv_avatar = getView().findViewById(R.id.iv_edit_avatar);
        if(this.gender.equals("male")){
            iv_avatar.setImageResource(R.drawable.male);
        }else if(this.gender.equals("female")){
            iv_avatar.setImageResource(R.drawable.female);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mContext = (ToAvatarFromEdit) getActivity();
        dContext = (ToDisplayFromEdit) getActivity();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_edit_profile_, container, false);
        getActivity().setTitle("My Profile");
        button_Save = view.findViewById(R.id.button_Save);
        iv_avatar = view.findViewById(R.id.iv_edit_avatar);


        iv_avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.startSelectAvatar();
            }
        });



        button_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_fname = view.findViewById(R.id.et_edit_fname);
                et_lname = view.findViewById(R.id.et_edit_lname);
                String fname = et_fname.getText().toString();
                String lname = et_lname.getText().toString();
                if(fname.equals("")){
                    et_fname.setError("First name can't be empty");
                }
                if(lname.equals("")){
                    et_lname.setError("Last name can't be empty");
                }
                if(gender.equals("")){
                    Toast.makeText(getActivity(), "Select an Avatar!!", Toast.LENGTH_SHORT).show();
                }
                if(!fname.equals("")&&!lname.equals("")&&!gender.equals("")){
                    Person p = new Person(et_fname.getText().toString(), et_lname.getText().toString(), gender);
                    dContext.startDisplayAvatar(p);
                }


            }
        });


        return view;
    }

    public interface ToAvatarFromEdit{
        void startSelectAvatar();
    }

    public interface ToDisplayFromEdit{
        void startDisplayAvatar(Person p);
    }

}
