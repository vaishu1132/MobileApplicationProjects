package com.example.inclass10intro;

public class Person {
    String fname, lname, gender;

    public Person(String fname, String lname, String gender) {
        this.fname = fname;
        this.lname = lname;
        this.gender = gender;
    }


}
