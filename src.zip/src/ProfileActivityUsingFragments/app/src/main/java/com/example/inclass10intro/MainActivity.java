//Group 08
//Name: Vaishali Krishnamurthy, Nivedita Veeramanigandan
//Student ID: 801077752, 801151512
package com.example.inclass10intro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements EditProfile_Fragment.ToAvatarFromEdit, SelectAvatarFragment.ToEditFromSelectAvatar,
EditProfile_Fragment.ToDisplayFromEdit{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.container,new EditProfile_Fragment(), "edit")
        .commit();

    }

    @Override
    public void startSelectAvatar() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, new SelectAvatarFragment(), "selectAvatar")
                .addToBackStack(null)
        .commit()
        ;
    }

    @Override
    public void onBackPressed() {
        if(getSupportFragmentManager().getBackStackEntryCount()>0){
            getSupportFragmentManager().popBackStack();
        }else{
            super.onBackPressed();
        }
    }

    @Override
    public void updateEdit(boolean isFemale) {
        getSupportFragmentManager().popBackStack();
        EditProfile_Fragment newEditFragment = (EditProfile_Fragment) getSupportFragmentManager().findFragmentByTag("edit");
        if (isFemale)newEditFragment.setGender("female");
        else newEditFragment.setGender("male");
    }

    @Override
    public void startDisplayAvatar(Person person) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, new DisplayFragment(person), "displayAvatar")
                .addToBackStack(null).commit();


    }
}
