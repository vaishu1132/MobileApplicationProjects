/*Name: Vaishali Krishnamurthy, Nivedita Veeramanigandan
Student ID: 801077752, 801151512*/
package com.example.inclass11;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import static android.view.View.INVISIBLE;

public class MainActivity extends AppCompatActivity implements MyAdapter.InteractWithRecyclerView {

    TextView tv_noExpenseText;
    ImageView bt_add;
    RecyclerView recyclerView;
    MyAdapter rv_adapter;
    private FirebaseFirestore db;
    RecyclerView.LayoutManager layoutManager;
    static ArrayList<Expense> expenseList = new ArrayList<>();



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == 200)
            if(data!= null && data.getExtras()!=null){
                if(data.getExtras().containsKey(AddExpense.EXPENSE)){
                    expenseList.add((Expense) data.getExtras().getSerializable(AddExpense.EXPENSE));
                    tv_noExpenseText.setVisibility(INVISIBLE);
                    rv_adapter = new MyAdapter(expenseList, MainActivity.this);
                    recyclerView.setAdapter(rv_adapter);
                    rv_adapter.notifyDataSetChanged();
                    System.out.println("new expense list is "+expenseList);
                }
            }
    }


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Expense App");



        db = FirebaseFirestore.getInstance();

        final String date_n = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(new Date());
        tv_noExpenseText = findViewById(R.id.tv_noExpenseText);
        tv_noExpenseText.setText("There is no expense to show. Please add your expenses from the menu.");

        bt_add = (ImageView) this.findViewById(R.id.bt_add);
        bt_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, AddExpense.class);
                startActivityForResult(i, 100);
            }
        });
        db.collection("Expenses")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            expenseList.clear();
                            tv_noExpenseText.setVisibility(INVISIBLE);
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                Expense expense = new Expense(document.getString("name"), document.get("category").toString(),
                                        document.getDouble("amount"), date_n,document.getId());
                                expenseList.add(expense);
                                Log.d("demo", document.getId() + " => " + document.getData());
                            }
                            if(expenseList.size()>0){
                                //tv_noExpenseText.setVisibility(INVISIBLE);
                                recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
                                layoutManager = new LinearLayoutManager(MainActivity.this);
                                recyclerView.setLayoutManager(layoutManager);
                                // specify an adapter (see also next example)
                                rv_adapter = new MyAdapter(expenseList, MainActivity.this);
                                recyclerView.setAdapter(rv_adapter);
                            }
                        } else {
                            Log.d("demo", "Error getting documents: ", task.getException());
                            Toast.makeText(MainActivity.this, "Some Error Occured in retriving the documents", Toast.LENGTH_SHORT).show();
                        }
                    }

                });
    }

    @Override
    public void deleteItem(int position) {
        expenseList.remove(position);
        Toast.makeText(this, "Expense Deleted!", Toast.LENGTH_SHORT).show();
        rv_adapter.notifyDataSetChanged();
        Log.d("demmmo", "deleteItem: "+expenseList.size());
        if(expenseList.size()<=0){
            tv_noExpenseText.setVisibility(View.VISIBLE);
        }
    }
}
