package com.example.inclass11;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddExpense extends AppCompatActivity {

    EditText et_expenseName, et_amount;
    Spinner spinner_category;
    Button bt_addExpense, bt_cancel;
    String date_val, expenseName, amount;
    static String EXPENSE = "expense";
    Double amount_val = 0.0;
    private FirebaseFirestore db;
    Expense addExpense;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);
        setTitle("Add Expense");
        db = FirebaseFirestore.getInstance();

        et_expenseName = findViewById(R.id.et_expenseName);
        et_amount = (EditText) findViewById(R.id.et_amount);

        spinner_category = findViewById(R.id.spinner_category);

        bt_addExpense = findViewById(R.id.bt_addExpense);
        bt_cancel = findViewById(R.id.bt_cancel);
        date_val = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(new Date());

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.category_list, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner_category.setAdapter(adapter);
        spinner_category.setOnItemSelectedListener(new spinnerOnItemSelectedListener());

        //Validation of all fields and storing it as an Expense object and updating in Firebase

        bt_addExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_expenseName.getText().toString().equals("")) {
                    et_expenseName.setError("Required field");
                    Toast.makeText(AddExpense.this, "Missing the expense name!", Toast.LENGTH_SHORT).show();
                } else if (et_amount.getText().toString().equals("")) {
                    et_amount.setError("Required field");
                    Toast.makeText(AddExpense.this, "Missing amount!", Toast.LENGTH_SHORT).show();
                } else if (spinner_category.getSelectedItem().toString().trim().equals("Select")) {
                    //spinner_category.setPrompt("Choose a category");
                    Toast.makeText(AddExpense.this, "Select a category!", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        amount_val = Double.parseDouble(et_amount.getText().toString());
                        System.out.println("Amount is " + amount_val);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                    addExpense = new Expense(et_expenseName.getText().toString(), spinner_category.getSelectedItem().toString(), amount_val, date_val,"");
                    db.collection("Expenses")
                            .add(addExpense)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    Log.d("demo", "Expense Successfully added!");
                                    addExpense.docId = documentReference.getId();
                                    Intent intent = new Intent();
                                    intent.putExtra("expense", addExpense); //sending values in Firebase and intent to MainActivity
                                    setResult(200, intent);
                                    finish();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.d("demo", "Some Error occured");
                        }
                    });
                }
            }
        });

        bt_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Intent in = new Intent(AddExpense.this, MainActivity.class);
                startActivity(in);

            }
        });
    }
    static  class spinnerOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

        }

        @Override
        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }
    }
}
