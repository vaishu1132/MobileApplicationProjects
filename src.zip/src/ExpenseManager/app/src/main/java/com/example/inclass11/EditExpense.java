package com.example.inclass11;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EditExpense extends AppCompatActivity {

    EditText et_editExpenseName, et_editAmount;
    Spinner spinner_editCategory;
    Button bt_save, bt_editCancel;
    Expense expen;
    FirebaseFirestore db;
    String spinnerPos, edit_expName, edit_category;
    Double edit_amount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_expense);
        setTitle("Edit Expense");

        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.edit_category_list, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        et_editExpenseName = findViewById(R.id.et_editExpenseName);
        et_editAmount = findViewById(R.id.et_editAmount);
        System.out.println("Edit amount is "+et_editAmount.getText().toString());
        spinner_editCategory = (Spinner) findViewById(R.id.spinner_editCategory);
        spinner_editCategory.setAdapter(adapter);
        spinner_editCategory.setOnItemSelectedListener(new AddExpense.spinnerOnItemSelectedListener());

        bt_save = findViewById(R.id.bt_save);
        bt_editCancel = findViewById(R.id.bt_editCancel);

        if(getIntent().getExtras()!=null){
                expen = (Expense) getIntent().getExtras().getSerializable(ShowExpense.EDIT);
                Log.d("edit", "edit obj is" +expen);
                et_editExpenseName.setText(expen.name);
                et_editAmount.setText(expen.amount.toString());
                int spin_position = adapter.getPosition(expen.category);
//                Log.d("spinner", "spinner selected: "+spin_position);
                spinner_editCategory.setSelection(spin_position);
        }

        final String date_val = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(new Date());
        db = FirebaseFirestore.getInstance();

        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //saving values in Firebase and intent to MainActivity
                if(et_editExpenseName.getText().toString().equals("")){
                    et_editExpenseName.setError("Edit the expense name");
                    Toast.makeText(EditExpense.this, "Edit the expense name", Toast.LENGTH_SHORT).show();
                }
                else if(et_editAmount.getText().toString().equals("")){
                    et_editAmount.setError("Edit the amount");
                    Toast.makeText(EditExpense.this, "Edit the amount", Toast.LENGTH_SHORT).show();
                }
                else {
                    edit_expName = et_editExpenseName.getText().toString();
                    edit_amount = Double.valueOf(et_editAmount.getText().toString());
                    edit_category = spinner_editCategory.getSelectedItem().toString();
                    db.collection("Expenses").document(expen.docId).update(
                            "name", edit_expName,
                            "category", edit_category,
                            "amount", edit_amount,
                            "date", date_val
                    ).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            //Toast.makeText(EditExpense.this, "Successfully edited", Toast.LENGTH_SHORT).show();
                        }
                    });
                    Intent back_intent = new Intent(EditExpense.this, MainActivity.class);
                    startActivity(back_intent);
                    finish();
                }
            }
        });

        bt_editCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    static  class spinnerOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        }

        @Override
        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }
    }
}
