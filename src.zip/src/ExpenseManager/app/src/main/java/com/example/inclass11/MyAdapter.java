package com.example.inclass11;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    private final ArrayList<Expense> exData;
    static String KEY = "expense";
    private MainActivity ctx;
    Expense exp;
    public InteractWithRecyclerView interact;
    private FirebaseFirestore db;

    public MyAdapter(ArrayList<Expense> exData, MainActivity mainActivity) {
        this.exData = exData;
        this.ctx = (MainActivity) mainActivity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview,parent,false);
        ViewHolder vh = new ViewHolder(layout);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder,final int position) {
        interact = (InteractWithRecyclerView) ctx;
        exp = exData.get(position);

        holder.tv_expName.setText(exp.getName());

        holder.tv_amount.setText("$"+exp.getAmount().toString());

        holder.expense = exp;
        holder.recycler_linearlayout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                db = FirebaseFirestore.getInstance();
                db.collection("Expenses").document(exData.get(position).docId)
                        .delete()
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                interact.deleteItem(position);

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                            }
                        });
                return false;
            }
        });

    }


    @Override
    public int getItemCount() {
        return exData.size();
    }

    public interface InteractWithRecyclerView {
        void deleteItem(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tv_expName, tv_amount;
        Expense expense;
        LinearLayout recycler_linearlayout;

        @Override
        public String toString() {
            return "ViewHolder{" +
                    "tv_expName=" + tv_expName +
                    ", tv_amount=" + tv_amount +
                    '}';
        }

        public ViewHolder(final @NonNull View itemView) {
            super(itemView);
            tv_expName = itemView.findViewById(R.id.tv_categoryName);
            tv_amount = itemView.findViewById(R.id.tv_amount);
            recycler_linearlayout = itemView.findViewById(R.id.recycler_linearlayout);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(itemView.getContext(), ShowExpense.class);
                    i.putExtra(KEY, expense);
                    v.getContext().startActivity(i);
                }
            });
        }
    }
}
