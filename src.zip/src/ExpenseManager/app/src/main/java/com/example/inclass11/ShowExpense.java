package com.example.inclass11;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ShowExpense extends AppCompatActivity {

    TextView tv_showName, tv_showCategory, tv_showAmount, tv_showDate;
    Button bt_showEditExpense, bt_close;
    static String EDIT = "edit";
    Expense exp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_expense);
        setTitle("Show Expense");

        tv_showName = findViewById(R.id.tv_showName);
        tv_showCategory = findViewById(R.id.tv_showCategory);
        tv_showAmount = findViewById(R.id.tv_showAmount);
        tv_showDate = findViewById(R.id.tv_showDate);
        bt_showEditExpense = findViewById(R.id.bt_showEditExpense);
        bt_close = findViewById(R.id.bt_showClose);

        if(getIntent().getExtras()!=null){
            exp = (Expense) getIntent().getExtras().getSerializable(MyAdapter.KEY);
            tv_showName.setText(exp.name);
            tv_showCategory.setText(exp.category);
            tv_showAmount.setText("$"+exp.amount.toString());
            tv_showDate.setText(exp.date);
        }
        bt_showEditExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent edit = new Intent(ShowExpense.this, EditExpense.class);
                edit.putExtra(EDIT,exp);
                startActivity(edit);
            }
        });

        bt_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent close = new Intent(ShowExpense.this, MainActivity.class);
                startActivity(close);
                finish();
            }
        });
    }
}
