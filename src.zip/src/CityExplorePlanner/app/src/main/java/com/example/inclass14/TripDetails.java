package com.example.inclass14;

import java.io.Serializable;
import java.util.ArrayList;

public class TripDetails implements Serializable {
    String tripName, cityName;
    String cityId;
    String docId;
    String latitude, longitude;
    ArrayList<PlaceDetails> placeDetails;

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public TripDetails(String tripName, String cityName, String cityId, String docId, String latitude, String longitude, ArrayList<PlaceDetails> placeDetails) {
        this.tripName = tripName;
        this.cityName = cityName;
        this.cityId = cityId;
        this.docId = docId;
        this.latitude = latitude;
        this.longitude = longitude;
        this.placeDetails = placeDetails;
    }

    @Override
    public String toString() {
        return "TripDetails{" +
                "tripName='" + tripName + '\'' +
                ", cityName='" + cityName + '\'' +
                ", cityId='" + cityId + '\'' +
                ", docId='" + docId + '\'' +
                ", latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                ", placeDetails=" + placeDetails +
                '}';
    }

    public ArrayList<PlaceDetails> getPlaceDetails() {
        return placeDetails;
    }

    public void setPlaceDetails(ArrayList<PlaceDetails> placeDetails) {
        this.placeDetails = placeDetails;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

}
