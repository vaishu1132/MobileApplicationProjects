package com.example.inclass14;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class PlaceAdapter extends RecyclerView.Adapter<PlaceAdapter.ViewHolder> {

    RecyclerView p_recyclerView;
    PlaceAdapter p_rv_adapter;
    RecyclerView.LayoutManager p_rv_layoutManager;
    ArrayList<PlaceDetails> placeDetailsArrayList;
    public static PlaceAdapter.InteractWithRecyclerView interactMain;

    public PlaceAdapter(ArrayList<PlaceDetails> placeDetails, Context ctx) {
        this.placeDetailsArrayList = placeDetails;
        interactMain = (PlaceAdapter.InteractWithRecyclerView) ctx;
    }
    @NonNull
    @Override
    public PlaceAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rv_layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_places_row_layout, parent, false);
        PlaceAdapter.ViewHolder viewHolder = new PlaceAdapter.ViewHolder(rv_layout);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull PlaceAdapter.ViewHolder holder, final int position) {
        holder.placeName.setText(placeDetailsArrayList.get(position).name);
        String imageURl = placeDetailsArrayList.get(position).imageUrl;
        Picasso.get().load(imageURl).into(holder.placeImage);
        holder.addPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                interactMain.getDetails(placeDetailsArrayList.get(position));

            }
        });

    }

    @Override
    public int getItemCount() {
        return placeDetailsArrayList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView placeName;
        ImageView placeImage;
        ImageButton addPlace;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            placeName = itemView.findViewById(R.id.tv_placename);
            placeImage = itemView.findViewById(R.id.iv_icon);
            addPlace = itemView.findViewById(R.id.ib_addPlace);
        }
    }

    public interface InteractWithRecyclerView{
        public void getDetails(PlaceDetails placeDetails);
    }
}
