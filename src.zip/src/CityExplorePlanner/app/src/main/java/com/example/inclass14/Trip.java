package com.example.inclass14;

import java.io.Serializable;

public class Trip implements Serializable {
    String Trip, city;

    @Override
    public String toString() {
        return "Trip{" +
                "Trip='" + Trip + '\'' +
                ", city='" + city + '\'' +
                '}';
    }

    public Trip(String trip, String city) {
        Trip = trip;
        this.city = city;
    }

    public String getTrip() {
        return Trip;
    }

    public void setTrip(String trip) {
        Trip = trip;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
