//Name: Vaishali Krishnamurthy, Nivedita Veeramanigandan
//        Student ID: 801077752, 801151512
package com.example.inclass14;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MyMainAdapter.InteractWithRecyclerView{
    ImageButton imageButton;
    RecyclerView recyclerView;

    MyMainAdapter rv_adapter;
    RecyclerView.LayoutManager rv_layoutManager;
    static ArrayList<TripDetails> mainTripList = new ArrayList<>();
    private FirebaseFirestore db;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);

        rv_layoutManager = new LinearLayoutManager(getApplicationContext());

        recyclerView.setLayoutManager(rv_layoutManager);
        if (requestCode == 100 && resultCode == 200){
            if(data!=null && data.getExtras()!=null) {
                TripDetails trip = (TripDetails) data.getExtras().get("Trip");
                //Add to firebase db
                mainTripList.add(trip);

                rv_adapter = new MyMainAdapter(mainTripList, MainActivity.this);

                recyclerView.setAdapter(rv_adapter);

                Log.d("mainlist", "onActivityResult: " + mainTripList);
            }
        }

        if (requestCode == 1000 && resultCode == 2000 && data!=null){
            Log.d("demo","Lets see if this works!");
            int position = data.getExtras().getInt("position");
            Log.d("clicked item", "clicked item: "+mainTripList.get(position));
            mainTripList.get(position).placeDetails.add((PlaceDetails) data.getExtras().getSerializable("placesDetails"));

            db.collection("Trips").document(mainTripList.get(position).docId).update("placeDetails", mainTripList.get(position).placeDetails);
            recyclerView = findViewById(R.id.recyclerView);
            recyclerView.setHasFixedSize(true);

            rv_layoutManager = new LinearLayoutManager(getApplicationContext());

            recyclerView.setLayoutManager(rv_layoutManager);
            rv_adapter = new MyMainAdapter(mainTripList, MainActivity.this);

            recyclerView.setAdapter(rv_adapter);
            rv_adapter.notifyDataSetChanged();
        }
    }

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Trips");
        db = FirebaseFirestore.getInstance();

        imageButton = findViewById(R.id.ib_add);
        recyclerView = findViewById(R.id.recyclerView);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toAddTrip = new Intent(MainActivity.this, AddTrip.class);
                startActivityForResult(toAddTrip, 100);
            }
        });

        db.collection("Trips")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            mainTripList.clear();
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                TripDetails tripDetails = new TripDetails(document.getString("tripName"), document.get("cityName").toString(),
                                        document.getString("cityId"),document.getId(), "", "", new ArrayList<PlaceDetails>());
                                mainTripList.add(tripDetails);
                                Log.d("demo", document.getId() + " => " + document.getData());
                            }
                            if(mainTripList.size()>0){
                                recyclerView = findViewById(R.id.recyclerView);
                                recyclerView.setHasFixedSize(true);

                                rv_layoutManager = new LinearLayoutManager(getApplicationContext());

                                recyclerView.setLayoutManager(rv_layoutManager);
                                // specify an adapter
                                rv_adapter = new MyMainAdapter(mainTripList, MainActivity.this);
                                recyclerView.setAdapter(rv_adapter);
                            }
                        } else {
                            Log.d("demo", "Error getting documents: ", task.getException());
                            Toast.makeText(MainActivity.this, "Some Error occured in retrieving the documents", Toast.LENGTH_SHORT).show();
                        }
                    }

                });
    }

    @Override
    public void callMainActivity(int position, ArrayList<PlaceDetails> tripDetails) {
            Intent toPlaces = new Intent(MainActivity.this,Places.class);
            toPlaces.putExtra("position",position);
            toPlaces.putExtra("Places", tripDetails);
            startActivityForResult(toPlaces, 1000);
    }
}

