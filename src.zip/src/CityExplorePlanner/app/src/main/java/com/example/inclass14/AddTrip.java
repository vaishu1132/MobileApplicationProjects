package com.example.inclass14;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class AddTrip extends AppCompatActivity implements AddTripAdapter.OnItemClickListener{
    EditText tripName, cityName;
    Button search, addTrip;
    RecyclerView at_recyclerView;
    RecyclerView.Adapter at_rv_adapter;
    RecyclerView.LayoutManager at_rv_layoutManager;
    final ArrayList<TripDetails> TripList = new ArrayList<>();
    private FirebaseFirestore db;
    TripDetails tripDetails;
    TripDetails trip;
    ArrayList<TripDetails> mainPageTripList = new ArrayList<>();


    String api_key = "AIzaSyAYZeQUIii1M5AmNcOFui5dZHokE8saLJw";
    String base_url = "https://maps.googleapis.com/maps/api/place/";
    String uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_trip);
        tripName = findViewById(R.id.et_tripName);
        cityName = findViewById(R.id.et_cityName);
        search = findViewById(R.id.bt_search);
        addTrip = findViewById(R.id.bt_addTrip);
        at_recyclerView = findViewById(R.id.recyclerView2);
        db = FirebaseFirestore.getInstance();
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uri = "https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyDh2Z9BqCGDC0iClXwvPgF0zJz6KlJPW08&types=(cities)&input="+cityName.getText().toString();
                Log.d("demo", "onClick: uri = " +uri);
                new getJson().execute(uri);
            }
        });

        addTrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tripName.getText().toString().equals("")){
                    tripName.setError("Please enter Trip name");
                }else if(cityName.getText().toString().equals("")){
                    cityName.setError("Please select a City");
                }
                else{

                    for (int i =0; i<TripList.size(); i++) {
                        if (TripList.get(i).cityName.equals(cityName.getText().toString())) {
                            trip = TripList.get(i);
                            break;
                        }
                    }

                    db.collection("Trips")
                            .add(trip)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    Log.d("demo", "onSuccess: DB record inserted");
                                    trip.docId = documentReference.getId();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("demo", "onFailure: DB record insertion unsuccessful");
                            }
                        });
                    //mainPageTripList.add(trip);

                    Intent toHomePage = new Intent(AddTrip.this, MainActivity.class);
                    toHomePage.putExtra("Trip", trip);
                    Log.d("before intent:", "onClick: "+trip);
                    setResult(200, toHomePage);
                    //startActivity(toHomePage);
                    finish();
                }
            }
        });
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    @Override
    public void onItemClick(int position) {

        cityName.setText(TripList.get(position).getCityName());

    }

    public class getJson extends AsyncTask<String, Void, ArrayList<TripDetails>> {

        @SuppressLint("WrongThread")
        @Override
        protected ArrayList<TripDetails> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;


            try {
                String url = strings[0];

                System.out.println(url);

                URL urlB = new URL(url);
                String cityId, cityName;
                String [] cityNamelist;

                connection = (HttpURLConnection) urlB.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF-8");

                    JSONObject root = new JSONObject(json);
                    JSONArray predictions = root.getJSONArray("predictions");

                    TripList.clear();

                    for (int i=0; i<predictions.length();i++){
                        JSONObject city = predictions.getJSONObject(i);
                        cityId = city.getString("place_id");
                        cityName = city.getString("description");
                        cityNamelist = cityName.split(",");
                        cityName = cityNamelist[0] +","+cityNamelist[1];
                        tripDetails = new TripDetails(tripName.getText().toString(), cityName, cityId, "", "","",new ArrayList<PlaceDetails>());
                        TripList.add(tripDetails);
                    }

                }
                Log.d("demo", "doInBackground: TripList= "+TripList );
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return TripList;

        }

        @Override
        protected void onPostExecute(ArrayList<TripDetails> tripDetails) {
            super.onPostExecute(tripDetails);

            at_recyclerView.setHasFixedSize(true);

            at_rv_layoutManager = new LinearLayoutManager(getApplicationContext());

            at_recyclerView.setLayoutManager(at_rv_layoutManager);

            at_rv_adapter = new AddTripAdapter(tripDetails, AddTrip.this, AddTrip.this);

            at_recyclerView.setAdapter(at_rv_adapter);

        }
    }
}
