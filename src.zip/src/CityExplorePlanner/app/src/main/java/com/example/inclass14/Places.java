package com.example.inclass14;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class Places extends AppCompatActivity implements PlaceAdapter.InteractWithRecyclerView{

    RecyclerView p_recyclerView;
    PlaceAdapter p_rv_adapter;
    RecyclerView.LayoutManager p_rv_layoutManager;
    static ArrayList<PlaceDetails> placeDetails1;
    ArrayList<PlaceDetails> placeDetails = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places);
        setTitle("Add Places");

       // placeDetails = getIntent().getExtras().getString("Places");
        placeDetails = (ArrayList<PlaceDetails>) getIntent().getSerializableExtra("Places");

        p_recyclerView = findViewById(R.id.rv_places1);

        p_recyclerView.setHasFixedSize(true);

        p_rv_layoutManager = new LinearLayoutManager(Places.this);

        p_recyclerView.setLayoutManager(p_rv_layoutManager);
        // specify an adapter
        p_rv_adapter = new PlaceAdapter(placeDetails, Places.this);
        p_recyclerView.setAdapter(p_rv_adapter);

    }

    @Override
    public void getDetails(PlaceDetails placeDetails1) {
        //store each place in a placelist
        //map this placelist to a particular trip
       // ArrayList<TripDetails> tripDetailsArrayList = (ArrayList<TripDetails>) getIntent().getExtras().getSerializable("global");
        int position = getIntent().getExtras().getInt("position");

        Intent intent =  new Intent();
        intent.putExtra("placesDetails", placeDetails1);
        intent.putExtra("position",position);
        setResult(2000, intent);
        finish();


    }
}
