package com.example.inclass14;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;

public class AddTripAdapter extends RecyclerView.Adapter<AddTripAdapter.ViewHolder> {

    ArrayList<TripDetails> TripList;
    private OnItemClickListener newOnItemClickListener;
    Context ctx;

    public AddTripAdapter(ArrayList<TripDetails> tripList, OnItemClickListener newOnItemClickListener, AddTrip addTrip) {
        TripList = tripList;
        this.newOnItemClickListener = newOnItemClickListener;
        this.ctx = addTrip;
    }

    @NonNull
    @Override
    public AddTripAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rv_layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_addtrip_row_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(rv_layout, newOnItemClickListener);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull AddTripAdapter.ViewHolder holder, int position) {

        holder.cityName.setText(TripList.get(position).getCityName());

    }

    @Override
    public int getItemCount() {
        return TripList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView cityName;
        OnItemClickListener onItemClickListener;
        public ViewHolder(@NonNull final View itemView, OnItemClickListener onItemClickListener) {
            super(itemView);
            cityName = itemView.findViewById(R.id.tv_cityName2);
            this.onItemClickListener = onItemClickListener;
            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {
            onItemClickListener.onItemClick(getAdapterPosition());

        }
    }
    public interface OnItemClickListener {
        void onItemClick(int position);
    }
}
