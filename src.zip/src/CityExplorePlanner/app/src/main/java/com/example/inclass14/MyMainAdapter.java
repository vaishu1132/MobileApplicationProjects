package com.example.inclass14;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MyMainAdapter extends RecyclerView.Adapter<MyMainAdapter.ViewHolder> {

    ArrayList<TripDetails> tripList = new ArrayList<>();
    static String [] locations;
    Context ctx;
    String selected;
    RecyclerView recyclerViewPlaces;
    RecyclerView.Adapter rv_adapterPlaces;
    RecyclerView.LayoutManager rv_layoutManagerPlaces;
    public static MyMainAdapter.InteractWithRecyclerView interactMain;


    public MyMainAdapter(ArrayList<TripDetails> tripList, Context ctx) {
        this.tripList = tripList;
        interactMain = (MyMainAdapter.InteractWithRecyclerView) ctx;
        this.ctx = ctx;
    }

    @NonNull
    @Override
    public MyMainAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rv_layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_main_row_layout, parent, false);
        MyMainAdapter.ViewHolder viewHolder = new MyMainAdapter.ViewHolder(rv_layout);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyMainAdapter.ViewHolder holder, final int position) {
        holder.cityName.setText(tripList.get(position).getCityName());
        holder.tripName.setText(tripList.get(position).getTripName());
        holder.coordinates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String city_ID = tripList.get(position).cityId;
                String map_uri = "https://maps.googleapis.com/maps/api/place/details/json?key=AIzaSyDh2Z9BqCGDC0iClXwvPgF0zJz6KlJPW08&placeid="+city_ID;
                new getLocation(true, position).execute(map_uri, city_ID);

            }
        });

        selected = tripList.get(position).cityId;
        holder.places.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String city_ID = tripList.get(position).cityId;
                String map_uri = "https://maps.googleapis.com/maps/api/place/details/json?key=AIzaSyDh2Z9BqCGDC0iClXwvPgF0zJz6KlJPW08&placeid="+city_ID;
                new getLocation(false, position).execute(map_uri, city_ID);
//                String tlat, tlng;
//                tlat = tripList.get(position).latitude;
//                tlng = tripList.get(position).longitude;


            }
        });

        recyclerViewPlaces = holder.rv_places;
        recyclerViewPlaces.setHasFixedSize(true);

        rv_layoutManagerPlaces = new LinearLayoutManager(ctx);

        recyclerViewPlaces.setLayoutManager(rv_layoutManagerPlaces);
        Log.d("demo","Checking for triplist placedetails : "+tripList.get(position).placeDetails);
        rv_adapterPlaces = new IndentRVLayoutAdapter(tripList.get(position).placeDetails, ctx);

        recyclerViewPlaces.setAdapter(rv_adapterPlaces);

    }

    @Override
    public int getItemCount() {
        return tripList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView cityName, tripName;
        ImageView coordinates, places;
        RecyclerView rv_places;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cityName = itemView.findViewById(R.id.tv_cityName);
            tripName = itemView.findViewById(R.id.tv_tripName);
            coordinates = itemView.findViewById(R.id.iv_map);
            places = itemView.findViewById(R.id.iv_add);
            rv_places = itemView.findViewById(R.id.rv_places);

        }
    }

    public class getLocation extends AsyncTask<String, Void, ArrayList<TripDetails>>{

        boolean callMap;
        int pos;

        public getLocation(boolean callMap, int pos) {
            this.callMap = callMap;
            this.pos = pos;
        }

        @Override
        protected ArrayList<TripDetails> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;



            try {
                String url = strings[0];
                String cityId = strings[1];
                TripDetails currentrip = null;

                System.out.println(url);

                URL urlB = new URL(url);
                connection = (HttpURLConnection) urlB.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF-8");

                    JSONObject root = new JSONObject(json);
                    JSONObject location = root.getJSONObject("result").getJSONObject("geometry").getJSONObject("location");
                    String lat = location.getString("lat");
                    String lng = location.getString("lng");
//                    for (int i=0; i<tripList.size(); i++)
//                    {
//                        if (tripList.get(i).cityId.equals(cityId)){
//                            currentrip = tripList.get(i);
//                            currentrip.latitude = lat;
//                            currentrip.longitude = lng;
//                            tripList.remove(i);
//                            tripList.add(i, currentrip);
//                            break;
//                        }
//                    }

                    tripList.get(pos).latitude = lat;
                    tripList.get(pos).longitude = lng;

                    Log.d("lat and long", "doInBackground: " + tripList.get(pos).longitude + tripList.get(pos).latitude);


                }
            }
            catch (IOException ex) {
                ex.printStackTrace();
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return tripList;

        }

        @Override
        protected void onPostExecute(ArrayList<TripDetails> trips) {
            super.onPostExecute(trips);

            if(callMap){
                Intent intent = new Intent(ctx, MapsActivity.class);
                intent.putExtra("Maps", tripList);
                ctx.startActivity(intent);
            }else{
                String places_uri = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?key=AIzaSyDh2Z9BqCGDC0iClXwvPgF0zJz6KlJPW08&location="+trips.get(pos).latitude+","+trips.get(pos).longitude+"&radius=1000";
                new getPlaces(pos).execute(places_uri, trips.get(pos).cityId);
            }

        }
    }



    public class getPlaces extends AsyncTask<String, Void, ArrayList<PlaceDetails>> {

        int pos;

        public getPlaces(int pos) {
            this.pos = pos;
        }

        @Override
        protected ArrayList<PlaceDetails> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            ArrayList<PlaceDetails> placeList = new ArrayList<>();


            try {
                String url = strings[0];
                String cityId = strings[1];
                TripDetails currentrip = null;


                System.out.println(url);

                URL urlB = new URL(url);
                String name, icon;
                connection = (HttpURLConnection) urlB.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF-8");

                    JSONObject root = new JSONObject(json);
                    JSONArray results = root.getJSONArray("results");
                    placeList.clear();

                    for (int i=0; i<results.length();i++){
                        JSONObject places = results.getJSONObject(i);
                        PlaceDetails placeDetails = new PlaceDetails();
                        placeDetails.imageUrl = places.getString("icon");
                        placeDetails.name = places.getString("name");

                        placeList.add(placeDetails);
                    }

                    Log.d("pos value", "doInBackground: "+pos);


                }
                Log.d("demo", "doInBackground: PlaceList= "+placeList);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return placeList;

        }

        @Override
        protected void onPostExecute(ArrayList<PlaceDetails> tripDetails) {

            super.onPostExecute(tripDetails);


//            Log.d("before places", "onPostExecute: "+tripDetails);
//            Intent toPlaces = new Intent(ctx,Places.class);
//            toPlaces.putExtra("postion",position);
//            toPlaces.putExtra("Places", tripDetails);
//            toPlaces.putExtra("global",tripList);
//            ((MainActivity) ctx).startActivityForResult(toPlaces, 1000);
//            ((MainActivity) ctx).finish();

            interactMain.callMainActivity(pos,tripDetails);
            //ctx.startActivity(toPlaces);

            Log.d("demo"," The function is coming here");

        }


    }

    public interface InteractWithRecyclerView{
        public void callMainActivity(int pos, ArrayList<PlaceDetails> tripDetails);
    }


}
//in this page write json code for places api