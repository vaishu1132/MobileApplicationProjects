package com.example.inclass14;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class IndentRVLayoutAdapter extends RecyclerView.Adapter<IndentRVLayoutAdapter.ViewHolder> {
    ArrayList<PlaceDetails> places;
    Context ctx;
//    public static IndentRVLayoutAdapter.InteractWithRecyclerView deletePlace;

    public IndentRVLayoutAdapter(ArrayList<PlaceDetails> places, Context ctx) {
        this.places = places;
//        deletePlace = (IndentRVLayoutAdapter.InteractWithRecyclerView) ctx;
    }

    @NonNull
    @Override
    public IndentRVLayoutAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rv_layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.indent_row_layout, parent, false);
        IndentRVLayoutAdapter.ViewHolder viewHolder = new IndentRVLayoutAdapter.ViewHolder(rv_layout);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull IndentRVLayoutAdapter.ViewHolder holder, final int position) {
        String imageURl = places.get(position).imageUrl;
        Picasso.get().load(imageURl).into(holder.iv_placeImage);
        holder.tv_placeName.setText(places.get(position).name);
        holder.iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                deletePlace.deletePlace(position);

            }
        });
    }

    @Override
    public int getItemCount() {
        return places.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView iv_delete, iv_placeImage;
        TextView tv_placeName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_delete = itemView.findViewById(R.id.iv_delete);
            iv_placeImage = itemView.findViewById(R.id.iv_placeImage);
            tv_placeName = itemView.findViewById(R.id.tv_savedPlaces);
        }
    }

    public interface InteractWithRecyclerView{
        public void deletePlace(int position);
    }
}
