/* Assignment InClass02
FileName: MainActivity.java
Team Members : Vaishali Krishnamurthy,Nivedita Veeramanigandan
Student ID : 801077752, 801151512
 */

package com.example.inclass03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class SelectAvatar extends AppCompatActivity implements View.OnClickListener{

    public static final String GENDER = "gender";
    ImageView iv_male, iv_female;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_avatar);
        setTitle("Select Avatar");

        iv_male = findViewById(R.id.imageView_male);
        iv_female = findViewById(R.id.imageView_female);

        iv_male.setOnClickListener(this);
        iv_female.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        if(view == iv_female)
        {
            Intent returnedData = new Intent();
            returnedData.putExtra(GENDER, "Female");

            setResult(RESULT_OK, returnedData);
            finish();
        }else if(view == iv_male){
                Intent returnedData = new Intent();
                returnedData.putExtra(GENDER, "Male");

                setResult(RESULT_OK, returnedData);
                finish();
        }
    }
}
