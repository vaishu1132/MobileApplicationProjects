/* Assignment InClass03
FileName: MainActivity.java
Team Members : Vaishali Krishnamurthy,Nivedita Veeramanigandan
Student ID : 801077752, 801151512
 */

package com.example.inclass03;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MyProfile extends AppCompatActivity {

    ImageView selectimage;
    private static final int REQ_CODE = 0x001;
    public static final String USER = "User";

    private TextView fname, lname;
    static String gender;
    private Button savebutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myprofile);
        setTitle("My Profile");
        selectimage = findViewById(R.id.imageView_default);

        fname = findViewById(R.id.editText_fname);
        lname = findViewById(R.id.editText_lname);
        savebutton = findViewById(R.id.button_save);

        selectimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent avatar_res = new Intent(MyProfile.this, SelectAvatar.class);
                startActivityForResult(avatar_res, REQ_CODE);
            }
        });


        savebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String first_name = fname.getText().toString();
                String last_name = lname.getText().toString();
                User u = new User(first_name,last_name,gender);

                if(first_name.equals("")) {
                    fname.setError("Can't be Empty");
                    //Toast.makeText(MyProfile.this, "CANT BE EMPTY !!", Toast.LENGTH_SHORT).show();
                }
                if(last_name.equals("")) {
                    lname.setError("Can't be Empty");
                    //Toast.makeText(MyProfile.this, "CANT BE EMPTY !!", Toast.LENGTH_SHORT).show();
                }
                if(!(first_name.equals("")) && !(last_name.equals(""))){
                    Intent sendUser = new Intent(MyProfile.this, DisplayProfile.class);
                    sendUser.putExtra(USER,u);
                    startActivity(sendUser);
                }

            }

        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        if(requestCode == REQ_CODE && resultCode == RESULT_OK && data!=null){
            gender = data.getExtras().getString(SelectAvatar.GENDER);

            if(gender.equals("Female")){
                selectimage.setImageDrawable(getDrawable(R.drawable.female));
            }else {
                selectimage.setImageDrawable(getDrawable(R.drawable.male));
            }
        }
    }
}
