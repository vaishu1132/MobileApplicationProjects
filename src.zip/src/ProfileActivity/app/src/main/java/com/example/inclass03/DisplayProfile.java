/* Assignment InClass02
FileName: MainActivity.java
Team Members : Vaishali Krishnamurthy,Nivedita Veeramanigandan
Student ID : 801077752, 801151512
 */

package com.example.inclass03;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class DisplayProfile extends AppCompatActivity {

    ImageView disp_image;
    private TextView fullname, set_gen;
    Button edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_profile);
        setTitle("Display Profile");

        User res_user = (User) getIntent().getExtras().getSerializable(MyProfile.USER);
        fullname = findViewById(R.id.fullname);
        fullname.setText(res_user.fname + " " +res_user.lname);

        set_gen = findViewById(R.id.displaygender);
        set_gen.setText(res_user.gender);

        disp_image = findViewById(R.id.imageView_dp);

        if(res_user.gender.equals("Female")){
            disp_image.setImageDrawable(getDrawable(R.drawable.female));
        }else {
            disp_image.setImageDrawable(getDrawable(R.drawable.male));
        }

        edit = findViewById(R.id.button_edit);

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homepage = new Intent(DisplayProfile.this, MyProfile.class);
                startActivity(homepage);
            }
        });

    }


}
